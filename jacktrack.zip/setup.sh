#!/usr/bin/env bash
set -e
echo "Creating Flutter project..."
flutter create jacktrack_app
echo "Copying files..."
rm -rf jacktrack_app/lib
cp -R lib jacktrack_app/lib
cp pubspec.yaml jacktrack_app/pubspec.yaml
cp .gitignore jacktrack_app/.gitignore
echo "Installing dependencies..."
cd jacktrack_app
flutter pub get
echo "Done. You can now open jacktrack_app in your IDE or run flutter run."