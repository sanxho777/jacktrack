import 'package:flutter/material.dart';

class ScorecardScreen extends StatefulWidget {
  const ScorecardScreen({super.key});
  @override
  State<ScorecardScreen> createState() => _ScorecardScreenState();
}

class _ScorecardScreenState extends State<ScorecardScreen> {
  final Map<int, int> scores = {};

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Scorecard')),
      body: ListView.builder(
        itemCount: 18,
        itemBuilder: (context, index) {
          final hole = index + 1;
          return ListTile(
            title: Text('Hole $hole'),
            trailing: SizedBox(
              width: 100,
              child: TextField(
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(hintText: 'Strokes'),
                onChanged: (val) {
                  setState(() {
                    scores[hole] = int.tryParse(val) ?? 0;
                  });
                },
              ),
            ),
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        child: const Icon(Icons.save),
        onPressed: () {
          ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Scores saved')));
        },
      ),
    );
  }
}
