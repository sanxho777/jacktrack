import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:location/location.dart';

class MapScreen extends StatefulWidget {
  const MapScreen({super.key});
  @override
  State<MapScreen> createState() => _MapScreenState();
}

class _MapScreenState extends State<MapScreen> {
  GoogleMapController? _controller;
  LatLng _initialPosition = const LatLng(37.7749, -122.4194);
  final Location _locationService = Location();

  @override
  void initState() {
    super.initState();
    _locationService.getLocation().then((loc) {
      setState(() {
        _initialPosition = LatLng(loc.latitude!, loc.longitude!);
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('JackTrack')),
      drawer: Drawer(
        child: ListView(
          children: [
            ListTile(title: const Text('Map'), onTap: () => Navigator.pop(context)),
            ListTile(title: const Text('Scorecard'), onTap: () => Navigator.pushNamed(context, '/scorecard')),
            ListTile(title: const Text('History'), onTap: () => Navigator.pushNamed(context, '/history')),
          ],
        ),
      ),
      body: GoogleMap(
        initialCameraPosition: CameraPosition(
          target: _initialPosition,
          zoom: 16,
          tilt: 45,
        ),
        mapType: MapType.hybrid,
        markers: {
          Marker(markerId: const MarkerId('hole1'), position: _initialPosition),
        },
        myLocationEnabled: true,
        onMapCreated: (controller) => _controller = controller,
      ),
      floatingActionButton: FloatingActionButton(
        child: const Icon(Icons.my_location),
        onPressed: () {
          if (_controller != null) {
            _controller!.animateCamera(CameraUpdate.newLatLng(_initialPosition));
          }
        },
      ),
    );
  }
}
