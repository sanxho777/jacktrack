import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'services/ble_service.dart';
import 'screens/map_screen.dart';
import 'screens/scorecard_screen.dart';
import 'screens/history_screen.dart';

void main() {
  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => BleService()),
      ],
      child: const JackTrackApp(),
    ),
  );
}

class JackTrackApp extends StatelessWidget {
  const JackTrackApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'JackTrack',
      theme: ThemeData(primarySwatch: Colors.green),
      home: const MapScreen(),
      routes: {
        '/scorecard': (_) => const ScorecardScreen(),
        '/history': (_) => const HistoryScreen(),
      },
    );
  }
}
