import 'package:flutter_blue/flutter_blue.dart';
import 'package:flutter/material.dart';

class BleService extends ChangeNotifier {
  final FlutterBlue _ble = FlutterBlue.instance;
  List<ScanResult> scanResults = [];
  BluetoothDevice? connectedDevice;

  BleService() {
    startScan();
  }

  void startScan() {
    scanResults.clear();
    _ble.startScan(timeout: const Duration(seconds: 5)).listen((result) {
      if (!scanResults.any((r) => r.device.id == result.device.id)) {
        scanResults.add(result);
        notifyListeners();
      }
    }, onDone: () => _ble.stopScan());
  }

  Future<void> connect(BluetoothDevice device) async {
    await device.connect();
    connectedDevice = device;
    notifyListeners();
  }

  Future<void> disconnect() async {
    if (connectedDevice != null) {
      await connectedDevice!.disconnect();
      connectedDevice = null;
      notifyListeners();
    }
  }
}
