export const GOOGLE_MAPS_API_KEY = 'AIzaSyDihUDy04TBAkFznSjN1_1B6LEGSnzx_cY';
