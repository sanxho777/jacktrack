import React from 'react';
import { View, Dimensions } from 'react-native';
import MapView, { Marker } from 'react-native-maps';
import { GOOGLE_MAPS_API_KEY } from '../config';

const { width, height } = Dimensions.get('window');
const ASPECT_RATIO = width / height;

const CourseMap = ({ userLocation, balls }) => (
  <MapView
    style={{ flex: 1 }}
    initialRegion={{
      latitude: userLocation.latitude,
      longitude: userLocation.longitude,
      latitudeDelta: 0.01,
      longitudeDelta: 0.01 * ASPECT_RATIO,
    }}
    showsUserLocation
    provider={MapView.PROVIDER_GOOGLE}
    apiKey={GOOGLE_MAPS_API_KEY}
  >
    {balls.map(ball => (
      <Marker
        key={ball.id}
        coordinate={{ latitude: ball.lat, longitude: ball.lng }}
        title={`Ball ${ball.id}`}
      />
    ))}
  </MapView>
);

export default CourseMap;
