import { BleManager } from 'react-native-ble-plx';

class BleService {
  constructor() {
    this.manager = new BleManager();
  }

  startScan(onDeviceFound) {
    this.manager.startDeviceScan(null, null, (error, device) => {
      if (error) {
        console.error(error);
        return;
      }
      onDeviceFound(device);
    });
  }

  stopScan() {
    this.manager.stopDeviceScan();
  }

  connectToDevice(deviceId) {
    return this.manager.connectToDevice(deviceId)
      .then(device => device.discoverAllServicesAndCharacteristics());
  }
}

export default new BleService();
