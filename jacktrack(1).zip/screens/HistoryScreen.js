import React from 'react';
import { View, Text } from 'react-native';

const HistoryScreen = () => (
  <View><Text>Game History</Text></View>
);

export default HistoryScreen;
