import React from 'react';
import { View, Text } from 'react-native';

const ScorecardScreen = () => (
  <View><Text>Scorecard</Text></View>
);

export default ScorecardScreen;
