import React, { useState, useEffect } from 'react';
import { View, StyleSheet, Button } from 'react-native';
import CourseMap from '../components/CourseMap';
import BleService from '../services/BleService';

const HomeScreen = ({ navigation }) => {
  const [userLocation, setUserLocation] = useState({ latitude: 37.78825, longitude: -122.4324 });
  const [balls, setBalls] = useState([]);

  useEffect(() => {
    BleService.startScan(device => {
      // TODO: filter golf-ball devices by name or service
      setBalls(prev => [...prev, { id: device.id, lat: userLocation.latitude, lng: userLocation.longitude }]);
    });

    return () => BleService.stopScan();
  }, []);

  return (
    <View style={styles.container}>
      <CourseMap userLocation={userLocation} balls={balls} />
      <Button title="Scorecard" onPress={() => navigation.navigate('Scorecard')} />
    </View>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1 }
});

export default HomeScreen;
