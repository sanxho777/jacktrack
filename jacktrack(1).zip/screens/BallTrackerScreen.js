import React from 'react';
import { View, Text } from 'react-native';

const BallTrackerScreen = () => (
  <View><Text>Ball Tracker Details</Text></View>
);

export default BallTrackerScreen;
