import React, { useState } from 'react';
import { View, Text, TextInput, FlatList, StyleSheet, TouchableOpacity } from 'react-native';

export default function ScorecardScreen() {
  const [scores, setScores] = useState({});
  const holes = Array.from({ length: 18 }, (_, i) => i+1);

  const renderItem = ({ item }) => (
    <View style={styles.row}>
      <Text style={styles.hole}>Hole {item}</Text>
      <TextInput 
        style={styles.input}
        keyboardType="number-pad"
        onChangeText={val => setScores({ ...scores, [item]: parseInt(val) || 0 })}
        placeholder="Strokes"
      />
    </View>
  );

  return (
    <View style={styles.container}>
      <FlatList 
        data={holes}
        keyExtractor={item => item.toString()}
        renderItem={renderItem}
      />
      <TouchableOpacity style={styles.save} onPress={() => {}}>
        <Text style={styles.saveText}>Save Scores</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex:1, padding:16 },
  row: { flexDirection:'row', justifyContent:'space-between', marginBottom:12 },
  hole: { fontSize:16 },
  input: { width:80, borderBottomWidth:1 },
  save: { backgroundColor:'#4CAF50', padding:12, alignItems:'center', marginTop:16 },
  saveText: { color:'white', fontSize:16 }
});