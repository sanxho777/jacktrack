import React, { useState, useEffect, useContext } from 'react';
import { View, StyleSheet, TouchableOpacity } from 'react-native';
import MapView, { Marker } from 'react-native-maps';
import * as Location from 'expo-location';
import { BleContext } from '../services/BleContext';
import { Ionicons } from '@expo/vector-icons';

export default function MapScreen() {
  const [region, setRegion] = useState({
    latitude: 37.7749, longitude: -122.4194, latitudeDelta: 0.005, longitudeDelta: 0.005
  });
  const { devices } = useContext(BleContext);

  useEffect(() => {
    (async () => {
      let { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') return;
      let loc = await Location.getCurrentPositionAsync({});
      setRegion({
        latitude: loc.coords.latitude,
        longitude: loc.coords.longitude,
        latitudeDelta: 0.005,
        longitudeDelta: 0.005
      });
    })();
  }, []);

  return (
    <View style={styles.container}>
      <MapView style={styles.map} region={region} showsUserLocation>
        <Marker coordinate={region} title="You" />
        {devices.map(dev => (
          <Marker 
            key={dev.id}
            coordinate={{
              latitude: region.latitude + Math.random()*0.001 - 0.0005,
              longitude: region.longitude + Math.random()*0.001 - 0.0005
            }}
            title={dev.name || dev.id}
          />
        ))}
      </MapView>
      <TouchableOpacity style={styles.button} onPress={() => {}}>
        <Ionicons name="locate" size={24} color="white" />
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex:1 },
  map: { flex:1 },
  button: {
    position:'absolute', bottom:20, right:20, backgroundColor:'#2196F3',
    padding:12, borderRadius:30
  }
});