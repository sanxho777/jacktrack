import React, { createContext, useState, useEffect } from 'react';
import { BleManager } from 'react-native-ble-plx';

export const BleContext = createContext();

export const BleProvider = ({ manager, children }) => {
  const [devices, setDevices] = useState([]);
  const [connectedDevice, setConnectedDevice] = useState(null);

  useEffect(() => {
    manager.startDeviceScan(null, null, (error, device) => {
      if (error) return;
      setDevices(prev => prev.find(d => d.id === device.id) ? prev : [...prev, device]);
    });
    return () => manager.stopDeviceScan();
  }, []);

  const connect = async (device) => {
    await manager.connectToDevice(device.id);
    setConnectedDevice(device);
  };

  const disconnect = async () => {
    if (connectedDevice) {
      await manager.cancelDeviceConnection(connectedDevice.id);
      setConnectedDevice(null);
    }
  };

  return (
    <BleContext.Provider value={{ devices, connectedDevice, connect, disconnect }}>
      {children}
    </BleContext.Provider>
  );
};