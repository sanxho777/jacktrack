import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createDrawerNavigator } from '@react-navigation/drawer';
import MapScreen from './screens/MapScreen';
import ScorecardScreen from './screens/ScorecardScreen';
import HistoryScreen from './screens/HistoryScreen';
import { BleManager } from 'react-native-ble-plx';
import { BleProvider } from './services/BleContext';

const Drawer = createDrawerNavigator();

export default function App() {
  const bleManager = new BleManager();

  return (
    <BleProvider manager={bleManager}>
      <NavigationContainer>
        <Drawer.Navigator initialRouteName="Map">
          <Drawer.Screen name="Map" component={MapScreen} />
          <Drawer.Screen name="Scorecard" component={ScorecardScreen} />
          <Drawer.Screen name="History" component={HistoryScreen} />
        </Drawer.Navigator>
      </NavigationContainer>
    </BleProvider>
  );
}